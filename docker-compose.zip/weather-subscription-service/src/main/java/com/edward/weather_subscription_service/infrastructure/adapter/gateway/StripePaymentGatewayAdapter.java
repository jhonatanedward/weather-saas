package com.edward.weather_subscription_service.infrastructure.adapter.gateway;

public class StripePaymentGatewayAdapter {
}
