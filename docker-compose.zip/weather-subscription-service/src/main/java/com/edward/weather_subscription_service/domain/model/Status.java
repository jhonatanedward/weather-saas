package com.edward.weather_subscription_service.domain.model;

public enum Status {
    PENDING,
    ACTIVE
}
