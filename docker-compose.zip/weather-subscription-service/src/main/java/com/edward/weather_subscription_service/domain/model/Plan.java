package com.edward.weather_subscription_service.domain.model;

public enum Plan {
    PREMIUM,
    FREE
}
