package com.edward.weather_subscription_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherSubscriptionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
