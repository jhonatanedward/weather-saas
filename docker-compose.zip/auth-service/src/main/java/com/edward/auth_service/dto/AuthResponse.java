package com.edward.auth_service.dto;

public record AuthResponse(Long id, String username, String token) {}