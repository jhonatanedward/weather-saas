package com.edward.auth_service.controller.advice;


public record ErrorResponse (String error, String message){}
