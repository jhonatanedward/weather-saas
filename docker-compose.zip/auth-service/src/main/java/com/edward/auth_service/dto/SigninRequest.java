package com.edward.auth_service.dto;

public record SigninRequest(String username, String email, String password){}