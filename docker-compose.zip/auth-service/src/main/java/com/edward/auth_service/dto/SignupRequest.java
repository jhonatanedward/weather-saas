package com.edward.auth_service.dto;

public record SignupRequest (String username, String email, String password){}