package com.edward.weatherbff.domain.model.weather;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Coord {
    private double lon;
    private double lat;

}
