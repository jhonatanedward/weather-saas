package com.edward.weatherbff.domain.model.subscription;

public enum Plan {
    PREMIUM,
    FREE
}
