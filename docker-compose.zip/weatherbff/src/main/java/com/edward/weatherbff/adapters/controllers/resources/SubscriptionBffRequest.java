package com.edward.weatherbff.adapters.controllers.resources;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SubscriptionBffRequest {
    private String planType;
}
