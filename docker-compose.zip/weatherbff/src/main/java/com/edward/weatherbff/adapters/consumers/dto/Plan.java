package com.edward.weatherbff.adapters.consumers.dto;

public enum Plan {
    PREMIUM,
    FREE
}
